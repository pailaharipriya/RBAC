import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import UsersList from './components/UsersList';
import RolesList from './components/RolesList';
import PermissionsList from './components/PermissionsList';

function App() {
  const [activeTab, setActiveTab] = useState('users');

  const renderContent = () => {
    switch (activeTab) {
      case 'users':
        return <UsersList />;
      case 'roles':
        return <RolesList />;
      case 'permissions':
        return <PermissionsList />;
      default:
        return <UsersList />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-1">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;